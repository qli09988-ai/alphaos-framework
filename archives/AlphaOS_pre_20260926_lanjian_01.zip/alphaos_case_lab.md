# AlphaOS Case Lab

Rule: this file contains experiments and observations.
Nothing here becomes a formal AlphaOS rule unless approved in the Change Log and added to Core Spec.

---

## Case #001 — Embodied Intelligence

### Key findings

1. Industry bottleneck and profit pool are not the same thing.
   - Current industry bottleneck may be reliable real-world task execution / generalization.
   - Investable profit pools may instead appear in high-reliability components, data infrastructure, deployment, or software platforms.

2. “Low localization rate” is not sufficient evidence of a good investment.
   - Must check supply expansion, pricing power, customer adoption, and economics.

3. Commercial validation must be separated from investment timing.
   - CV answers “is the business becoming real?”
   - Expectation answers “has the market already priced it?”

4. Batch delivery is not enough.
   - Economic validation matters:
     revenue growth + margin improvement + cash conversion.

5. Existing business and new optionality must be analyzed separately.

6. Financial filings should be the primary source for company financial conclusions.

### Company cards

#### 震裕科技 — v0.8
Working type:
- strong base business + robot optionality

Key monitoring:
- small batch -> stable batch / repeat purchase
- base-business cash flow / receivables
- robot revenue becoming separately visible

#### 福立旺 — v0.8
Working type:
- base-business recovery + higher robot earnings elasticity

Key monitoring:
- planetary roller screw from sample/intention -> real paid order
- 3C customer concentration and profit durability
- robot revenue crossing meaningful scale

#### 五洲新春 — v0.8
Working type:
- base business under pressure + aggressive robot capacity expansion

Key monitoring:
- batch orders AND margin improvement
- capacity utilization
- supply expansion vs demand

#### 贝斯特 — v0.8
Working type:
- stable base business + very early robot optionality

Key monitoring:
- sample -> first paid small-batch order
- avoid mistaking technical capability for commercial validation

#### 万向钱潮 — v0.8
Working type:
- large manufacturing platform + strategic robot migration

Key monitoring:
- batch order + separately visible robot revenue
- whether robot business becomes large enough to affect group profit

---

## Case — 垣信卫星 / 千帆星座

Use:
- test pre-commercial signals
- test infrastructure / platform businesses
- study where “commercialization proof” starts before mature profitability

Key insight:
- infrastructure build-out ≠ mature business
- key transition is network build -> paying users / ARPU / utilization / unit economics

Potential future experiment:
> Historical rewind: if we go back to 2022/2023, which public signals would have been enough to put the company into a core observation pool before major strategic investors entered?

---

## Case — 鲁信创投

Use:
- test whether CV logic works for asset / venture-capital platforms

Finding:
- CV is not a natural fit for venture-capital / asset realization businesses.

Possible alternative:
- Asset Realization Stage
- NAV revaluation
- catalyst / exit pipeline
- look-through ownership

Status:
- not yet promoted to Core Spec
