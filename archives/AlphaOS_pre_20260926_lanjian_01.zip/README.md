# AlphaOS Portable Docs

Version: v0.1-working  
Purpose: keep AlphaOS portable across ChatGPT, Claude, DeepSeek, local agents, OpenClaw, etc.

## Files

- `alphaos_core_spec.md` — formal framework / source of truth
- `alphaos_status_board.md` — current progress and version boundary
- `alphaos_case_lab.md` — real-world cases used to pressure-test the framework
- `alphaos_backlog_changelog.md` — gaps, proposed changes, and approved version changes
- `alphaos_usage_protocol.md` — how any model/agent should use these files without causing memory drift

## Governance rule

**Core Spec is the source of truth.**

A case result does NOT automatically become a framework rule.

Any new rule must follow:

`Case finding -> Gap -> Proposed change -> Review -> Approved change -> Core Spec update`

This prevents memory drift and “chat-based rule mutation”.

## Migration

When moving to a new platform/model, provide these files first and instruct the model:

> Read `alphaos_core_spec.md` first. Treat it as the source of truth.  
> Use `alphaos_status_board.md` to continue from the current project state.  
> Use `alphaos_case_lab.md` only as evidence/cases, not as formal rules.  
> Do not promote anything in `alphaos_backlog_changelog.md` into Core Spec unless explicitly marked Approved.
