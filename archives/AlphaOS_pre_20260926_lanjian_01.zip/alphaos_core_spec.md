# AlphaOS Core Spec — v0.1 Working

Status: **formal framework / source of truth**  
Rule: only approved changes may be added here.

---

## 1. System goal

AlphaOS is a personal investment operating system for evidence-driven decision support.

It is NOT:
- an “AI that guarantees profit”;
- a model that invents trading numbers;
- a clone of the user’s thinking;
- a pure news-summary bot.

It SHOULD:
- preserve investment theses and decision history;
- track state changes;
- separate facts, inference, assumptions, and market expectations;
- use deterministic rules/code for numerical risk and position calculations;
- learn from review without allowing uncontrolled self-modification.

---

## 2. Core epistemic principle

> **Facts + Logic = View**

If facts and logic remain unchanged, the long-term view should not change merely because price fluctuates.

Short-term market state, sentiment, crowding, and expectation can change independently from long-term industry/company facts.

---

## 3. Main research chain

1. **Direction Engine** — why this direction / where real capital and policy resources are going
2. **Industry Lifecycle Engine** — where the industry is in its lifecycle
3. **Commercialization / Validation** — whether demand is real and repeatable
4. **Bottleneck Analysis** — what constrains scale
5. **Profit Pool Engine** — where excess profit can actually accumulate
6. **Company Position Engine** — which companies can capture that profit
7. **Expectation Engine** — what the market has already priced
8. **Execution Engine** — how to act
9. **Risk & Position Engine** — how much risk can be taken
10. **Review / Evaluation Loop** — what was right/wrong and what should be updated

---

## 4. 431 research framework

### 4 — four layers
- Macro
- Market
- Industry
- Company

### 3 — “three highs”
- High growth
- High profitability
- High moat

### 1 — key bottleneck
Find the true bottleneck / profit-pool node in the value chain.

Important:
- bottleneck ≠ moat
- bottleneck ≠ automatically a good investment
- low domestic penetration ≠ automatically high profit
- technical difficulty ≠ pricing power

---

## 5. Industry Lifecycle

Working lifecycle:

- L0 — Technical exploration
- L1 — Commercial validation
- L2 — Production / scale-up
- L3 — Scale expansion
- L4 — Mature competition

The system must always output the **current stage**, not every historical stage.

Historical stages are shown only in Learning/Audit mode.

---

## 6. Commercial Validation (CV)

Working ladder:

- CV0 — Demo / concept only
- CV1 — customer testing / sample
- CV2 — paid pilot / small-batch order
- CV3 — clear batch delivery
- CV4 — repeat purchase / repeated expansion
- CV5 — cross-customer / cross-industry replication

Important:
- CV is **commercial validation**, NOT an automatic buy signal.
- Investment timing must combine CV with market expectation.
- Preferred hunting zone is often where validation is improving rapidly while expectation is not yet saturated.

For businesses already in batch delivery, **economic validation** must also be checked:
- revenue ramp
- margin ramp
- cash conversion
- return on invested capital / payback
- pricing power

---

## 7. Profit Pool Engine

A potential profit pool must pass four tests:

1. Demand elasticity
2. Supply expansion difficulty
3. Substitutability / indispensability
4. Profit-capture ability

Additional required risk:
- **Supply Expansion Risk**

A good industry can still be a poor investment if supply expands faster than demand.

Profit pools can migrate as the industry lifecycle changes.

---

## 8. Company Position Engine

Internal research fields:

1. Base Business
2. Product / technical position
3. Commercial Validation
4. Customer position
5. Capacity / production schedule
6. Economics (revenue, margin, profit)
7. R&D / strategic commitment
8. Moat / key risks
9. Earnings Elasticity
10. Expectation

Default user-facing output should be compressed to:
- Current state
- Strongest evidence
- Biggest missing evidence / risk
- Next confirmation event
- Market expectation state

---

## 9. Base Business / Optionality Separation

When a new business is still small:

- analyze the existing business separately;
- analyze the new growth option separately;
- do not attribute existing profit growth to the new theme without evidence.

Questions:
- What currently supports the valuation?
- How sustainable is the base business?
- How large must the optional business become to change the profit curve?

---

## 10. Earnings Quality

Profit growth must be checked against:
- operating cash flow
- receivables
- inventory
- gross margin
- net margin
- capital expenditure
- working-capital changes

Rule:
> Profit growth without cash conversion is a yellow flag that requires explanation.

Financial filing priority:
1. periodic report / financial filing
2. company announcement / inquiry reply
3. IR / investor communication
4. customer / tender / procurement information
5. news and secondary summaries
6. market commentary

---

## 11. Expectation Engine

States:

- E1 — underpriced / largely unpriced
- E2 — expectation forming
- E3 — substantially priced
- E4 — expectation overdraft / very demanding expectations

Do not infer expectation from price rise alone.

Inputs include:
- fundamentals / orders / shipment / earnings expectations
- valuation vs history and peers
- relative price behavior
- crowding / turnover / participation
- reaction to catalysts

---

## 12. Reverse Expectation Model

Purpose:
> Ask what must happen in the future to justify today’s valuation.

Do NOT use it as a fake “fair price” calculator.

Process:
1. Base-business profit baseline
2. Current valuation requirement
3. Incremental profit gap
4. What new business revenue/margin/share would be required to fill the gap?
5. Compare implied requirements with industry reality

---

## 13. Market Regime Engine

States:
- R1 Fear / ice
- R2 Repair
- R3 Risk-on / main rise
- R4 Climax / overheating
- R5 Retreat

Inputs:
- index trend
- breadth
- turnover/liquidity
- sentiment structure
- mainline persistence

Market Regime gives risk posture, NOT exact position percentages.

---

## 14. Execution Engine

Keep three decisions separate:
- Investment Judgment
- Trade Judgment
- Risk Management

Exit taxonomy:
- S1 Thesis break
- S2 Expectation realization / overdraft
- S3 Swing structure break
- S4 Opportunity cost

Price stops are a last-resort risk fail-safe, not the primary thesis criterion.

---

## 15. Position Thesis Card

Each tracked position/company should store:
- stock / code / mode
- core causal thesis
- validation metrics
- catalysts
- strengthening conditions
- weakening / break conditions
- latest CV / expectation / regime states
- current action status
- missing evidence
- next confirmation event

The card stores **state + transition conditions**, not “good/bad company” labels.

---

## 16. Information hierarchy

A — Confirmed facts:
- filings
- exchange / regulator
- official procurement/tender
- customer disclosures

B — Leading evidence:
- IR
- supplier expansion
- hiring
- project filing / EIA
- industry conferences
- customer deployment

C — Weak signals:
- media reports
- social media
- supply-chain rumor
- expert chatter

Rule:
> Weak signals trigger investigation; they do not directly trigger investment action.

---

## 17. Controlled learning

AlphaOS should improve through:

Decision -> Evidence record -> Outcome -> Error diagnosis -> Proposed rule change -> Validation -> Human approval -> Version update

AI must NOT silently rewrite rules.

Use a Rule Registry / Change Log.

---

## 18. Output modes

### Decision Mode
Show:
- current state
- what changed
- implication
- next signal to watch

### Learning Mode
Expand:
- causal chain
- definitions
- comparisons
- why the conclusion follows

### Audit Mode
Show:
- source
- timestamp
- calculation
- assumptions
- confidence
- rule version

---

## 19. Foundation Model Test

For every module ask:

> If the next foundation model is 10x stronger, does this module still matter?

Durable assets:
- private state/history
- data
- thesis memory
- deterministic risk rules
- decision logs
- longitudinal evaluation

Model-only analysis is not the moat.
