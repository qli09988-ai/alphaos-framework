# AlphaOS Backlog & Change Log

Purpose:
- prevent chat discoveries from silently mutating the framework;
- keep v0.1 and v0.2 boundaries clean.

---

## A. Approved changes already incorporated into Core Spec

### CHG-001
Source: embodied-intelligence case
Change:
- bottleneck != profit pool
Status: Approved / in Core Spec

### CHG-002
Source: component commercialization analysis
Change:
- add Supply Expansion Risk to Profit Pool
Status: Approved / in Core Spec

### CHG-003
Source: 震裕 / 福立旺 / 五洲 cases
Change:
- add Base Business / Optionality Separation
Status: Approved / in Core Spec

### CHG-004
Source: financial-statement review
Change:
- Financial Filing First
- add Earnings Quality checks
Status: Approved / in Core Spec

### CHG-005
Source: batch-delivery cases
Change:
- CV must include economic validation after scale begins
Status: Approved / in Core Spec

### CHG-006
Source: long-form output overload
Change:
- Decision / Learning / Audit output modes
Status: Approved / in Core Spec

---

## B. v0.1 MUST finish

### TODO-001 — Risk & Position Engine
Need:
- portfolio risk budget
- single-position risk budget
- volatility / structure inputs
- correlation / concentration
- max portfolio loss logic
- deterministic calculation rules
- no LLM-invented percentages

### TODO-002 — Thesis Card + Event Monitor
Need:
- state fields
- validation metrics
- strengthening / weakening / break conditions
- catalyst calendar
- T-3~7, T, T+1 behavior
- proactive updates

### TODO-003 — Data Requirement Mapping
For each decision point:
- data needed
- source
- frequency
- automation
- backup source
- timestamp / provenance / confidence

### TODO-004 — Review / Evaluation Loop
Need:
- record decision at time T
- outcome later
- diagnose data / reasoning / rule / execution failure
- propose rule change
- validate change
- human approval
- version update

---

## C. v0.2 backlog

### BL-001 — Market Discovery / Information Latency
Problem:
- large models often learn themes after the market has already moved.
- retail investors lack first-hand industrial research channels.

Goal:
- real-time market anomaly -> active investigation

Possible inputs:
- relative strength
- turnover / volume anomaly
- multi-stock co-movement
- sector diffusion
- unexplained strength
- order-flow / tick changes
- latest announcements / tenders / patents / IR

Rule:
- price anomaly triggers investigation, not investment.

### BL-002 — Pre-Commercial Signal Engine
Goal:
- identify “uncertainty falling before mature commercialization”.

Potential signal ladder:
- policy / resource allocation
- capacity construction
- procurement / tenders
- engineering deployment
- customer test
- repeat procurement
- revenue
- margin / cash flow

### BL-003 — Asset Realization Engine
Source:
- 鲁信创投 case

For venture-capital / asset platforms:
- look-through ownership
- NAV
- IPO / exit stage
- lock-up
- realization probability
- catalyst timing

### BL-004 — live market data layer
Potential:
- tonghuasun-codex
- market data APIs
- WebSocket / MCP
- account state

Use:
- market reality layer
- expectation state refresh
- regime
- later market discovery

---

## D. Change-control template

Whenever a case reveals a problem, record:

- Gap ID:
- Date:
- Case:
- Existing rule:
- Observed failure:
- Proposed change:
- Why it matters:
- v0.1 critical? yes/no
- Validation needed:
- Status: Proposed / Testing / Approved / Rejected
- Core Spec version updated:
