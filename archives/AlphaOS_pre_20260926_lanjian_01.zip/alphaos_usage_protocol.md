# AlphaOS Usage Protocol

Use this file when giving AlphaOS to another model/platform.

---

## 1. Reading order

1. `alphaos_core_spec.md`
2. `alphaos_status_board.md`
3. `alphaos_case_lab.md`
4. `alphaos_backlog_changelog.md`

---

## 2. Source-of-truth rule

`alphaos_core_spec.md` is authoritative.

Do NOT:
- treat an old chat answer as a formal rule;
- promote a case observation to a system rule automatically;
- overwrite formal definitions based on one new example.

---

## 3. When analyzing a new company

Default order:

1. Industry / Direction
2. Lifecycle
3. Commercial Validation
4. Bottleneck
5. Profit Pool
6. Base Business
7. Company Position
8. Earnings Quality
9. Earnings Elasticity
10. Expectation
11. Reverse Expectation when needed
12. Market Regime
13. Execution / Risk

Use only the depth required to change a decision.

---

## 4. Evidence discipline

Every important conclusion should identify whether it is:

- FACT
- CALCULATION
- INFERENCE
- HYPOTHESIS
- MISSING EVIDENCE

Use first-party filings before secondary reporting for financial facts.

---

## 5. State updates

A company card should change only when new evidence changes:
- CV
- Thesis strength
- Expectation
- risk / action

“No news” can itself become negative evidence if a time-sensitive thesis repeatedly fails to progress.

---

## 6. Preventing memory drift

At the end of a meaningful research session:

1. update the relevant Case Lab entry;
2. add any new gap to Backlog;
3. update Status Board if project progress changed;
4. update Core Spec ONLY for approved rules;
5. increment version when formal behavior changes.

---

## 7. Platform migration prompt

Use:

> You are continuing development of AlphaOS.  
> Read the attached AlphaOS files in this order: Core Spec, Status Board, Case Lab, Backlog/Change Log, Usage Protocol.  
> Treat Core Spec as the authoritative framework.  
> Do not silently merge case observations or backlog ideas into Core Spec.  
> Preserve version boundaries.  
> When you find a framework gap, record it as a proposed change first.  
> Distinguish facts, calculations, inference, hypotheses, and missing evidence.
